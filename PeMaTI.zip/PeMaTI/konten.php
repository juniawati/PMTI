<?php
    if(empty($_GET)) {
        include "konten/home.php";
}   else if($_GET['p']=='home') {
    include "konten/home.php";
}  else if($_GET['p']=='pengaduan') {
    include "konten/pengaduan.php";
}  else if($_GET['p']=='riwayat') {
    include "konten/riwayat.php";
}  