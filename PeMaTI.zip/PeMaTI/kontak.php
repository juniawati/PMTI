<?php
include "admin/koneksi.php";

$name = $_POST['name'];
$email = $_POST['email'];
$subject = $_POST['subject'];
$message = $_POST['message'];


$sql="INSERT INTO kontak(nama, email, subjek, pesan) values ('$name', '$email', '$subject', '$message')";

echo $sql;

mysqli_query($koneksi, $sql);
header("location:index.php");
?>