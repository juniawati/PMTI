<?php
include "koneksi.php";

$nim = $_POST['nim'];
$nama = $_POST['nama'];
$angkatan = $_POST['angkatan'];


$sql="INSERT INTO tb_mahasiswa(nim, nama, angkatan) values ('$nim', '$nama', '$angkatan')";

echo $sql;

mysqli_query($koneksi, $sql);
header("location:index.php?p=mahasiswa");
?>