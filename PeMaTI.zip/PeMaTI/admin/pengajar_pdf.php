<?php
// memanggil library FPDF
require('library/fpdf.php');
include 'koneksi.php';
 
// intance object dan memberikan pengaturan halaman PDF
$pdf=new FPDF('P','mm','A4');
$pdf->AddPage();
 
$pdf->SetFont('Times','B',13);
$pdf->Cell(200,10,'LAPORAN PENGADUAN MAHASISWA',0,1,'C');
$pdf->Cell(200,5,'Terkait Tenaga Pengajar',0,0,'C');
 
$pdf->Cell(10,15,'',0,1);
$pdf->SetFont('Times','B',9);
$pdf->Cell(10,7,'NO',1,0,'C');
$pdf->Cell(65,7,'NAMA',1,0,'C');
$pdf->Cell(115,7,'KELUHAN',1,0,'C');
 
 
$pdf->Cell(10,7,'',0,1);
$pdf->SetFont('Times','',10);
$no=1;
$data = mysqli_query($koneksi,"SELECT  * FROM tb_tenaga_ajar");
while($d = mysqli_fetch_array($data)){
  $pdf->Cell(10,6, $no++,1,0,'C');
  $pdf->Cell(65,6, $d['nama_mhs'],1,0);  
  $pdf->Cell(115,6, $d['keluhan'],1,1);
}
 
$pdf->Output();
 
?>