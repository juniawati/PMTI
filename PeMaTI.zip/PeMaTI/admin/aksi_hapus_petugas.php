<?php
include "koneksi.php";

$id=$_GET['id'];
$sql="DELETE FROM `tb_admin` WHERE id_admin = '$id'";

// echo $sql

mysqli_query($koneksi, $sql);

 header("location:index.php?p=petugas");
?>