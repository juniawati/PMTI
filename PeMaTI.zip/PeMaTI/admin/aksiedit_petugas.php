<?php
include "koneksi.php";

$id = $_POST['id'];
$nama = $_POST['nama'];
$username = $_POST['username'];
$password = $_POST['password'];
$jabatan = $_POST['jabatan'];

$sql="UPDATE tb_admin set
nama='$nama',
username='$username',
password = '$password',
jabatan = '$jabatan'
where id_admin='$id'";

// echo $sql

mysqli_query($koneksi, $sql);

 header("location:index.php?p=petugas");
?>