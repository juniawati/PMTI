<?php
include "koneksi.php";

$id=$_GET['id'];
$sql="DELETE FROM `tb_mahasiswa` WHERE id_mahasiswa = '$id'";

// echo $sql

mysqli_query($koneksi, $sql);

 header("location:index.php?p=mahasiswa");
?>