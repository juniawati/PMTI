<?php
include "koneksi.php";

$id = $_POST['id'];
$nim = $_POST['nim'];
$nama = $_POST['nama'];
$angkatan = $_POST['angkatan'];

$sql="UPDATE tb_mahasiswa set
nim='$nim',
nama='$nama',
angkatan = '$angkatan'
where id_mahasiswa='$id'";

// echo $sql

mysqli_query($koneksi, $sql);

 header("location:index.php?p=mahasiswa");
?>