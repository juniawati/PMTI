<?php
    if(empty($_GET)) {
        include "konten/dashboard.php";
}   else if($_GET['p']=='dashboard') {
    include "konten/dashboard.php";
}  else if($_GET['p']=='sarpras') {
    include "konten/sarpras.php";
}  else if($_GET['p']=='mahasiswa') {
    include "konten/mahasiswa.php";
}  else if($_GET['p']=='tambahmahasiswa') {
    include "konten/tambahmahasiswa.php";
}   else if($_GET['p']=='editmahasiswa') {
    include "konten/editmahasiswa.php";
}   else if($_GET['p']=='tenaga_ajar') {
    include "konten/tenaga_ajar.php";
}   else if($_GET['p']=='staff') {
    include "konten/staff.php";
}   else if($_GET['p']=='petugas') {
    include "konten/petugas.php";
}   else if($_GET['p']=='tambahpetugas') {
    include "konten/tambahpetugas.php";
}  else if($_GET['p']=='editpetugas') {
    include "konten/editpetugas.php";
}  else if($_GET['p']=='contact') {
    include "konten/contact.php";
}  else if($_GET['p']=='export') {
    include "konten/export.php";
}  else if($_GET['p']=='profile') {
    include "konten/profile.php";
}  