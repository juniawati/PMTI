<?php
include "koneksi.php";

$nama = $_POST['nama'];
$username = $_POST['username'];
$password = $_POST['password'];
$jabatan = $_POST['jabatan'];


$sql="INSERT INTO tb_admin(nama, username, password, jabatan) values ('$nama', '$username', '$password', '$jabatan')";

echo $sql;

mysqli_query($koneksi, $sql);
header("location:index.php?p=petugas");
?>