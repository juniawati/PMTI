<?php
include "koneksi.php";

$id = $_POST['id'];
$nama = $_POST['nama'];
$username = $_POST['username'];
$password = $_POST['password'];

$sql="UPDATE tb_admin set
nama='$nama',
username='$username',
password = '$password'
where id_admin='$id'";

// echo $sql

mysqli_query($koneksi, $sql);

 header("location:index.php?p=profile&BerhasilUpdate");
?>