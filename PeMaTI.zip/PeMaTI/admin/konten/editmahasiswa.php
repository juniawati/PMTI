<?php
$id=$_GET['id'];
$sql="SELECT * FROM tb_mahasiswa where id_mahasiswa='$id'";
$query=mysqli_query($koneksi, $sql);
$r=mysqli_fetch_array($query);
 ?>
<!-- JUDUL PAGE -->
<div class="pagetitle">
  <h1>Edit Data Mahasiswa</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.php?p=mahasiswa">Mahasiswa</a></li>
      <li class="breadcrumb-item active">Edit Data</li>
    </ol>
  </nav>
</div>
<!-- BATAS JUDUL PAGE -->

        <div class="card">
            <div class="card-body">
              <h5 class="card-title">Edit Data Mahasiswa</h5>

              <!-- Edit Data Mahasiswa-->
              <form method="post" action="aksiedit_mahasiswa.php" enctype="multipart/form-data">
              <div class="row mb-3">
                  <label  class="col-sm-2 col-form-label">ID </label>
                  <div class="col-sm-10">
                    <input type="number" class="form-control" name="id" readonly value="<?= $r['id_mahasiswa'] ?>">
                  </div>
                </div>
                <div class="row mb-3">
                  <label  class="col-sm-2 col-form-label">NIM</label>
                  <div class="col-sm-10">
                    <input type="number" class="form-control" name="nim" value="<?= $r['nim'] ?>">
                  </div>
                </div>
                <div class="row mb-3">
                  <label  class="col-sm-2 col-form-label">Nama</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="nama" value="<?= $r['nama'] ?>">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputPassword" class="col-sm-2 col-form-label">Password</label>
                  <div class="col-sm-10">
                    <select name="angkatan" id="" class="form-control">
                        <option value="<?= $r['angkatan'] ?>"> <?= $r['angkatan'] ?> </option>
                        <option value="2019">2019</option>
                        <option value="2020">2020</option>
                        <option value="2021">2021</option>
                        <option value="2022">2022</option>
                    </select>
                  </div>
                </div>
        
                
                <div class="row mb-3">
                  <label class="col-sm-2 col-form-label"></label>
                  <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary">Edit Data</button>
                  </div>
                </div>

              </form><!-- End General Form Elements -->

            </div>
          </div>