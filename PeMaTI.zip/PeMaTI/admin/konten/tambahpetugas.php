<!-- JUDUL PAGE -->
<div class="pagetitle">
  <h1>Tambah Data Petugas</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.php?p=petugas">Petugas</a></li>
      <li class="breadcrumb-item active">Tambah Data</li>
    </ol>
  </nav>
</div>
<!-- BATAS JUDUL PAGE -->

        <div class="card">
            <div class="card-body">
              <h5 class="card-title">Tambah Data Petugas</h5>

              <!-- Tambah Data Petugas-->
              <form method="post" action="aksitambah_petugas.php" enctype="multipart/form-data">
                <div class="row mb-3">
                  <label  class="col-sm-2 col-form-label">Nama</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="nama" placeholder="Masukkan Nama Lengkap Petugas">
                  </div>
                </div>
                <div class="row mb-3">
                  <label  class="col-sm-2 col-form-label">Username</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="username" placeholder="Masukkan Username">
                  </div>
                </div>
                <div class="row mb-3">
                  <label  class="col-sm-2 col-form-label">Password</label>
                  <div class="col-sm-10">
                    <input type="password" class="form-control" name="password" placeholder="Masukkan Password">
                  </div>
                </div>
                <div class="row mb-3">
                  <label  class="col-sm-2 col-form-label">Jabatan</label>
                  <div class="col-sm-10">
                    <select name="jabatan" id="" class="form-control">
                        <option value="">Pilih Jabatan</option>
                        <option value="Administrator">Administrator</option>
                        <option value="Operator">Operator</option>
                        <option value="Reviewer">Reviewer</option>
                    </select>
                  </div>
                </div>
        
                
                <div class="row mb-3">
                  <label class="col-sm-2 col-form-label"></label>
                  <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary">Input Data</button>
                  </div>
                </div>

              </form><!-- End General Form Elements -->

            </div>
          </div>