<!-- JUDUL PAGE -->
<div class="pagetitle">
  <h1>Data Petugas</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.php?p=dashboard">Admin</a></li>
      <li class="breadcrumb-item active">Petugas</li>
    </ol>
  </nav>
</div>
<!-- BATAS JUDUL PAGE -->

<!-- KONTEN PENGADUAN --> <br> <br>
<div class="card">
            <div class="card-body"><br>
            <a href="index.php?p=tambahpetugas" style="text-decoration=none">
              <button type="button" class="btn btn-light"><i class="bi bi-plus"></i>Tambah Petugas</button>
            </a>
              <h5 class="card-title">Data Petugas</h5>

              <!-- Data Petugas -->
              <table class="table table-hover">
                <thead>
                  <tr >
                    <th scope="col">No</th>
                    <th scope="col">Nama Petugas</th>
                    <th scope="col">Username</th>
                    <th scope="col">Password</th>
                    <th scope="col">Jabatan</th>
                    <th scope="col">Aksi</th>
                  </tr>
                </thead>

                <tbody>
                    <?php
                        $no = 0;
                        $sql="SELECT * FROM tb_admin";
                        $query=mysqli_query($koneksi, $sql);
                        while($r=mysqli_fetch_array($query)) : $no++;
                    ?>
                  <tr>
                    <th> <?= $no  ?> </th>
                    <td><?= $r['nama'] ?></td>
                    <td><?= $r['username'] ?></td>
                    <td><?= $r['password'] ?></td>
                    <td><?= $r['jabatan'] ?></td>
                    <td >
                        <a href="index.php?p=editpetugas&id=<?= $r['id_admin'] ?>" style="color:black;"> <i class="bi bi-pencil" ></i> Edit </a> 
                        <a href="aksi_hapus_petugas.php?id=<?= $r['id_admin'] ?>" onclick="return confirm('Apakah anda yakin menghapus data ini?')";  style="color:black;"> <i class ="bi bi-trash"></i> Hapus </a> 
                    </td>
                  </tr>
                        <?php endwhile ?>
    
                </tbody>
              </table>
              <!-- End Table with hoverable rows -->

            </div>
          </div>
<!-- BATAS KONTEN PENGADUAN -->