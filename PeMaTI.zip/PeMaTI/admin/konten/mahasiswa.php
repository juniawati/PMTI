<!-- JUDUL PAGE -->
<div class="pagetitle">
  <h1>Data Mahasiswa</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.php?p=dashboard">Admin</a></li>
      <li class="breadcrumb-item active">Mahasiswa</li>
    </ol>
  </nav>
</div>
<!-- BATAS JUDUL PAGE -->

<!-- KONTEN PENGADUAN --> <br> <br>
<div class="card">
            <div class="card-body"><br>
            <a href="index.php?p=tambahmahasiswa" style="text-decoration=none">
              <button type="button" class="btn btn-light"><i class="bi bi-plus"></i>Tambah Mahasiswa</button>
            </a>
              <h5 class="card-title">Data Mahasiswa</h5>

              <!-- Data Mahasiswa -->
              <table class="table table-hover">
                <thead>
                  <tr >
                    <th scope="col">No</th>
                    <th scope="col">NIM</th>
                    <th scope="col">Nama Mahasiswa</th>
                    <th scope="col">Angkatan</th>
                    <th scope="col">Aksi</th>
                  </tr>
                </thead>

                <tbody>
                    <?php
                        $no = 0;
                        $sql="SELECT * FROM tb_mahasiswa";
                        $query=mysqli_query($koneksi, $sql);
                        while($r=mysqli_fetch_array($query)) : $no++;
                    ?>
                  <tr>
                    <th> <?= $no  ?> </th>
                    <td><?= $r['nim'] ?></td>
                    <td><?= $r['nama'] ?></td>
                    <td><?= $r['angkatan'] ?></td>
                    <td >
                        <a href="index.php?p=editmahasiswa&id=<?= $r['id_mahasiswa'] ?>" style="color:black;"> <i class="bi bi-pencil" ></i> Edit </a> 
                        <a href="aksi_hapus_mahasiswa.php?id=<?= $r['id_mahasiswa'] ?>" onclick="return confirm('Apakah anda yakin menghapus data ini?')";  style="color:black;"> <i class ="bi bi-trash"></i> Hapus </a> 
                    </td>
                  </tr>
                        <?php endwhile ?>
    
                </tbody>
              </table>
              <!-- End Table with hoverable rows -->

            </div>
          </div>
<!-- BATAS KONTEN PENGADUAN -->