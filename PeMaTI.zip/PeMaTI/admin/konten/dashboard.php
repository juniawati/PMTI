

<div class="pagetitle">
  <h1>Dashboard</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="#">Home</a></li>
      <li class="breadcrumb-item active">Dashboard</li>
    </ol>
  </nav>
</div><!-- End Page Title -->

<section class="section dashboard">
  <div class="row">

    <!-- Left side columns -->
    <div class="col-lg-8">
      <div class="row">

        <!-- Sarana Prasarana Card -->
        <div class="col-xxl-4 col-md-6">
          <div class="card info-card sales-card">
            <div class="card-body">
              <h5 class="card-title">Laporan Pengaduan <span> Sarana Prasarana</span></h5>

              <div class="d-flex align-items-center">
                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                  <i class="bi bi-cast"></i>
                </div>
                <div class="ps-3">
                  <?php 
                  $sarpras = mysqli_query(  $koneksi, "SELECT * FROM tb_sarpras");
                  $jml_sarpras = mysqli_num_rows($sarpras); ?>
                  <h6> <?= $jml_sarpras ?></h6>
                  <span class="text-primary small pt-1 fw-bold">Laporan</span> 

                </div>
              </div>
            </div>

          </div>
        </div><!-- End Sarana Prasarana Card -->

        <!-- Tenaga Pengajar Card -->
        <div class="col-xxl-4 col-md-6">
          <div class="card info-card revenue-card">
            <div class="card-body">
              <h5 class="card-title">Laporan Pengaduan <span>Tenaga Pengajar</span></h5>

              <div class="d-flex align-items-center">
                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                  <i class="bi bi-pen"></i>
                </div>
                <div class="ps-3"> 
                  <?php 
                  $pengajar =  mysqli_query(  $koneksi,"SELECT * FROM tb_tenaga_ajar");
                  $jml_pengajar = mysqli_num_rows($pengajar); ?>
                  <h6> <?= $jml_pengajar ?> </h6>
                  <span class="text-success small pt-1 fw-bold">Laporan</span> 

                </div>
              </div>
            </div>

          </div>
        </div><!-- End Tenaga Pengajar Card -->

        <!-- Customers Card -->
        <div class="col-xxl-4 col-xl-12">

          <div class="card info-card customers-card">
            <div class="card-body">
              <h5 class="card-title">Laporan Pengaduan <span>Staff</span></h5>

              <div class="d-flex align-items-center">
                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                  <i class="bi bi-people"></i>
                </div>
                <div class="ps-3">
                  <?php 
                  $staff = mysqli_query(  $koneksi, "SELECT * FROM tb_staff");
                  $jml_staff = mysqli_num_rows($staff); ?>
                  <h6> <?= $jml_staff ?> </h6>
                  <span class="text-danger small pt-1 fw-bold">Laporan</span> 

                </div>
              </div>

            </div>
          </div>

        </div><!-- End Customers Card -->

        <!-- GRAFIK -->
        <div class="col-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Grafik Laporan </h5>

              <!-- GRAFIK  Chart -->
              <div id="reportsChart"></div>

              <script>
                document.addEventListener("DOMContentLoaded", () => {
                  new ApexCharts(document.querySelector("#reportsChart"), {
                    series: [{
                      name: 'Sarana Prasarana',
                      data: [31, 40, 28, 51, 42, 82, 56],
                    }, {
                      name: 'Tenaga Pengajar',
                      data: [11, 32, 45, 32, 34, 52, 41]
                    }, {
                      name: 'Staff',
                      data: [15, 11, 32, 18, 9, 24, 11]
                    }],
                    chart: {
                      height: 350,
                      type: 'area',
                      toolbar: {
                        show: false
                      },
                    },
                    markers: {
                      size: 4
                    },
                    colors: ['#4154f1', '#2eca6a', '#ff771d'],
                    fill: {
                      type: "gradient",
                      gradient: {
                        shadeIntensity: 1,
                        opacityFrom: 0.3,
                        opacityTo: 0.4,
                        stops: [0, 90, 100]
                      }
                    },
                    dataLabels: {
                      enabled: false
                    },
                    stroke: {
                      curve: 'smooth',
                      width: 2
                    }
                  }).render();
                });
              </script>
              <!-- End GRAFIK Chart -->

            </div>

          </div>
        </div><!-- End GRAFIK -->
        </div>
    </div><!-- End Left side columns -->

    <!-- Right side columns -->
    <div class="col-lg-4">

      
      <!-- DIAGRAM LAPORAN -->
      <div class="card">
        <div class="card-body pb-0">
          <h5 class="card-title">Diagram Laporan <span></span></h5>

          <div id="trafficChart" style="min-height: 400px;" class="echart"></div>

          <script>
            document.addEventListener("DOMContentLoaded", () => {
              echarts.init(document.querySelector("#trafficChart")).setOption({
                tooltip: {
                  trigger: 'item'
                },
                legend: {
                  top: '5%',
                  left: 'center'
                },
                series: [{
                  name: 'Access From',
                  type: 'pie',
                  radius: ['40%', '70%'],
                  avoidLabelOverlap: false,
                  label: {
                    show: false,
                    position: 'center'
                  },
                  emphasis: {
                    label: {
                      show: true,
                      fontSize: '18',
                      fontWeight: 'bold'
                    }
                  },
                  labelLine: {
                    show: false
                  },
                  data: [{
                      value: 4,
                      name: 'Sarana Prasarana'
                    },
                    {
                      value: 3,
                      name: 'Tenaga Pengajar'
                    },
                    {
                      value: 2,
                      name: 'Staff'
                    }
                  ]
                }]
              });
            });
          </script>

        </div>
      </div><!-- BATAS DIAGRAM LAPORAN -->


    </div><!-- End Right side columns -->

  </div>
</section>
