<!-- JUDUL PAGE -->
<div class="pagetitle">
  <h1>Laporan Pengaduan Tenaga Pengajar</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.php?p=dashboard">Admin</a></li>
      <li class="breadcrumb-item active">Tenaga Pengajar</li>
    </ol>
  </nav>
</div>
<!-- BATAS JUDUL PAGE -->

<!-- KONTEN PENGADUAN --> <br> <br>
<div class="card">
            <div class="card-body">
              <h5 class="card-title">Laporan Pengaduan Tenaga Pengajar</h5>

              <!-- Laporan Pengaduan Tenaga Pengajar -->
              <table class="table table-hover">
                <thead>
                  <tr >
                    <th scope="col">No</th>
                    <th scope="col">Nama Mahasiswa</th>
                    <th scope="col">Keluhan</th>
                    <th scope="col">Status</th>
                    <th scope="col">Aksi</th>
                  </tr>
                </thead>

                <tbody>
                    <?php
                        $no = 0;
                        $sql="SELECT * FROM tb_tenaga_ajar";
                        $query=mysqli_query($koneksi, $sql);
                        while($r=mysqli_fetch_array($query)) :$no++
                    ?>
                  <tr>
                    <th> <?= $no  ?> </th>
                    <td><?= $r['nama_mhs'] ?></td>
                    <td><?= $r['keluhan'] ?></td>
                    <td> Pending </td>
                    <td >
                        <a href="#"  onclick="return confirm('Apakah anda yakin menghapus data ini?')" style="color:black;"> <i class ="bi bi-trash"></i> Hapus </a> 
                    </td>
                  </tr>
                        <?php endwhile ?>
    
                </tbody>
              </table>
              <!-- End Table with hoverable rows -->

            </div>
          </div>
<!-- BATAS KONTEN PENGADUAN -->