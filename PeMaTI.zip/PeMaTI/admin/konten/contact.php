<!-- JUDUL PAGE -->
<div class="pagetitle">
  <h1>PESAN MASUK</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.php?p=dashboard">Admin</a></li>
      <li class="breadcrumb-item active">Pesan Masuk</li>
    </ol>
  </nav>
</div>
<!-- BATAS JUDUL PAGE -->

<!-- KONTEN PENGADUAN --> <br> <br>
<div class="card">
            <div class="card-body">
              <h5 class="card-title">Data Pesan Masuk </h5>

              <!-- Data Pesan Masuk -->
              <table class="table table-hover">
                <thead>
                  <tr >
                    <th scope="col">No</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Email</th>
                    <th scope="col">Subject</th>
                    <th scope="col">Isi Pesan</th>
                  </tr>
                </thead>

                <tbody>
                    <?php
                        $no = 0;
                        
                        $sql="SELECT * FROM kontak";
                        $query=mysqli_query($koneksi, $sql);
                        while($r=mysqli_fetch_array($query)) :$no++
                    ?>
                  <tr>
                    <th> <?= $no  ?> </th>
                    <td><?= $r['nama'] ?></td>
                    <td><?= $r['email'] ?></td>
                    <td><?= $r['subjek'] ?></td>
                    <td><?= $r['pesan'] ?></td>
                  </tr>
                        <?php endwhile ?>
    
                </tbody>
              </table>
              <!-- End Table with hoverable rows -->

            </div>
          </div>
<!-- BATAS KONTEN PENGADUAN -->