<!-- JUDUL PAGE -->
<div class="pagetitle">
  <h1>Data Acuan</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.php?p=dashboard">Admin</a></li>
      <li class="breadcrumb-item active">Data Acuan</li>
    </ol>
  </nav>
</div>
<!-- BATAS JUDUL PAGE -->

<!-- KONTEN PENGADUAN --> <br> <br>
<div class="card">
            <div class="card-body">
              <h5 class="card-title">Data Acuan</h5>

              <!-- Data Petugas -->
              <table class="table table-hover">
                <thead>
                  <tr >
                    <th scope="col">Nama File</th>
                    <th scope="col">Download</th>
                  </tr>
                </thead>

                <tbody>
                  <tr>
                    <td>Data Mahasiswa</td>
                    <td >
                        <a href="mahasiswa_pdf.php" target="_blank" style="color:black;"> <i class="bi bi-download" ></i> PDF </a> 
                    </td>
                  </tr>

                  <tr>
                    <td>Data Petugas</td>
                    <td >
                        <a href="petugas_pdf.php"  target="_blank" style="color:black;"> <i class="bi bi-download" ></i> PDF </a> 
                    </td>
                  </tr>

                  <tr>
                    <td>Data Pengaduan Sarana & Prasarana</td>
                    <td >
                        <a href="sarpras_pdf.php"  target="_blank" style="color:black;"> <i class="bi bi-download" ></i> PDF </a> 
                    </td>
                  </tr>

                  <tr>
                    <td>Data Pengaduan Tenaga Pengajar</td>
                    <td >
                        <a href="pengajar_pdf.php"  target="_blank" style="color:black;"> <i class="bi bi-download" ></i> PDF </a> 
                    </td>
                  </tr>

                  <tr>
                    <td>Data Pengaduan Staff</td>
                    <td >
                        <a href="staff_pdf.php"  target="_blank" style="color:black;"> <i class="bi bi-download" ></i> PDF </a> 
                    </td>
                  </tr>
    
                </tbody>
              </table>
              <!-- End Table with hoverable rows -->

            </div>
          </div>
<!-- BATAS KONTEN PENGADUAN -->