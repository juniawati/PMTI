<?php 
session_start();

include "admin/koneksi.php";

$username = $_POST['username'];
$password = $_POST['password'];

$query = "select * from tb_mahasiswa where nama='$username' and nim='$password'";
$data = mysqli_query($koneksi, $query);

$cek = mysqli_num_rows($data);

if ($cek > 0) {
    $row = mysqli_fetch_array($data);
    session_start();
    $_SESSION['nama'] = $row['nama'];
    $_SESSION['nim'] = $row['nim'];
    header("location:index.php"); 
} else {
    header("location:login.php?pesan=gagal#".$username."#".$password);
}

    