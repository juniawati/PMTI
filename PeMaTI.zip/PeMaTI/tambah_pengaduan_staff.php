<?php
session_start();
include "admin/koneksi.php";

$nama = $_SESSION['nama'];
$keluhan = $_POST['keluhan'];


$sql="INSERT INTO tb_staff(nama_mhs, keluhan) values ('$nama', '$keluhan')";

echo $sql;

mysqli_query($koneksi, $sql);
header("location:index.php?p=home&Terkirim");
?>