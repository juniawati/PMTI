
  <!-- ======= home Section ======= -->  
  <section id="home" class="d-flex align-items-center">

    <div class="container">
      <div class="row">
        <div class="col-lg-6 pt-5 pt-lg-0 order-2 order-lg-1 d-flex flex-column justify-content-center"> <br>
        <h1 data-aos="fade-up"> <b>Buat dirimu lebih nyaman di kampus!</b> </h1>
          <h2 data-aos="fade-up" data-aos-delay="400">"Ciptakan kampus yang membuatmu nyaman diam didalamnya."</h2>
          <div data-aos="fade-up" data-aos-delay="800">
            <a href="#about" class="btn-get-started scrollto">Mulai dari sini</a>
          </div>
        </div>
        <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="fade-left" data-aos-delay="200">
          <br> <br> <br>
          <img src="assets/img/people.png" class="img-fluid animated" alt="">
        </div>
      </div>
    </div>

  </section><!-- End Home -->

  <main id="main">

    
    <!-- ======= About Us Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>About Us</h2>
        </div>

        <div class="row content">
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="150">
            <p>
            PM-TI hadir sebagai wadah untuk menampung pengaduan yang ditujukan kepada dosen, staff, ataupun fasilitas didalamnya agar bisa menjadi lebih baik kedepannya.
PM-TI dapat digunakan oleh seluruh mahasiswa/i aktif program studi Teknologi Informasi. 

            </p>
            <ul>
              <li><i class="ri-check-double-line"></i> Wadah bagi ketidaknyamanan yang dirasakan mahasiswa</li>
              <li><i class="ri-check-double-line"></i> Acuan data bagi pihak atas untuk meindaklanjuti setiap permasalahan</li>
              <li><i class="ri-check-double-line"></i> Acuan data untuk saling memperbaiki</li>
            </ul>
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0" data-aos="fade-up" data-aos-delay="300">
            <p>
            Tujuan dari adanya website ini bukanlah untuk menyudutkan satu/dua belah pihak, namun agar kita bersama-sama dapat membangun Teknologi Informasi jauh lebih baik, baik dari segi mengajar ataupun fasilitas.
            </p>
          </div>
        </div>

      </div>
    </section><!-- End About Us Section -->

    <!-- ======= Counts Section ======= -->
    <section id="counts" class="counts">
      <div class="container">

        <div class="row">
          <div class="image col-xl-5 d-flex align-items-stretch justify-content-center justify-content-xl-start" data-aos="fade-right" data-aos-delay="150">
            <img src="assets/img/counts-img.svg" alt="" class="img-fluid">
          </div>

          <div class="col-xl-7 d-flex align-items-stretch pt-4 pt-xl-0" data-aos="fade-left" data-aos-delay="300">
            <div class="content d-flex flex-column justify-content-center">
              <div class="row">
                <div class="col-md-6 d-md-flex align-items-md-stretch">
                  <div class="count-box">
                    <i class="bi bi-emoji-smile"></i>
                    <span>HAPPY</span>
                    <p>Menciptakan suasana kampus TI yang bahagia.</p>
                  </div>
                </div>

                <div class="col-md-6 d-md-flex align-items-md-stretch">
                  <div class="count-box">
                    <i class="bx bi-display"></i>
                    <span>COMFORTABLE</span>
                    <p>Menciptakan kampus TI yang nyaman</p>
                  </div>
                </div>

                <div class="col-md-6 d-md-flex align-items-md-stretch">
                  <div class="count-box">
                    <i class="bi bi-chat-quote"></i>
                    <span >KOMUNIKATIF</span>
                    <p>Membuat lingkungan di kampus TI menjadi leboh komunikatif baik antara dosen, mahasiswa, dan staff</p>
                  </div>
                </div>

                <div class="col-md-6 d-md-flex align-items-md-stretch">
                  <div class="count-box">
                    <i class="bi bi-diagram-3 "></i>
                    <span >TERSTRUKTUR</span>
                    <p>Kampus TI memiliki data yang jelas dan terarah.</p>
                  </div>
                </div>
              </div>
            </div><!-- End .content-->
          </div>
        </div>

      </div>
    </section><!-- End Counts Section -->

    <!-- ======= Service Section ======= -->
    <section id="service" class="services">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>Services</h2>
          <p>Layanan yang tersedia dalam website ini </p>
        </div>

        <div class="row">
          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="100">
              <div class="icon"><i class="ri-community-line"></i></div>
              <h4 class="title"><a href="">Pengaduan Sarana Prasarana</a></h4>
              <p class="description">Melalui website ini kamu melaporkan kendala yang kamu alami terkait dengan sarana dan prasarana yang ada di kampus ini, khususnya di jurusan Teknologi Informasi. </p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="200">
              <div class="icon"><i class="ri-group-line"></i></div>
              <h4 class="title"><a href="">Pengaduan Tenaga Pengajar</a></h4>
              <p class="description">Melalui website ini kamu melaporkan kendala yang kamu alami terkait dengan tenaga pengajar/dosen yang ada di kampus ini, khususnya di jurusan Teknologi Informasi. </p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="300">
              <div class="icon"><i class="ri-user-3-line"></i></div>
              <h4 class="title"><a href="">Pengaduan Staff</a></h4>
              <p class="description">Melalui website ini kamu melaporkan kendala yang kamu alami terkait dengan Staff TU yang ada di kampus ini, khususnya di jurusan Teknologi Informasi. </p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="400">
              <div class="icon"><i class="ri-mail-check-line"></i></div>
              <h4 class="title"><a href="">Layanan Contact Person</a></h4>
              <p class="description">Melalui website ini, disediakan juga Contact Person yang bisa dihubungi ketika terdapat masalah dalam operasional website ini. </p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->

  
    <!-- ======= F.A.Q Section ======= -->
    <section id="faq" class="faq">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>Frequently Asked Questions</h2>
        </div>

        <div class="row faq-item d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
          <div class="col-lg-5">
            <i class="ri-question-line"></i>
            <h4>Apakah harus login terlebih dahulu untuk bisa mengadukan keluhan/masalah yang dialami?</h4>
          </div>
          <div class="col-lg-7">
            <p>
              Iya. Fitur pengaduan hanya tersedia ketika sudah login menggunakan akun yang disediakan.
            </p>
          </div>
        </div><!-- End F.A.Q Item-->

        <div class="row faq-item d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
          <div class="col-lg-5">
            <i class="ri-question-line"></i>
            <h4>Apakah mahasiswa diluar TI bisa login disini?</h4>
          </div>
          <div class="col-lg-7">
            <p>
              Tidak bisa, hanya mahasiswa TI aktif yang bisa login dan menggunakan fitur pengaduan ini. 
            </p>
          </div>
        </div><!-- End F.A.Q Item-->

        <div class="row faq-item d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="300">
          <div class="col-lg-5">
            <i class="ri-question-line"></i>
            <h4>Apakah semua dosen bisa melihat isi pengaduan yang ditulis?</h4>
          </div>
          <div class="col-lg-7">
            <p>
              Tidak. Data dari hasil pengaduan ini hanya bisa diakses oleh Administrator, Operator, dan Reviewer.
            </p>
          </div>
        </div><!-- End F.A.Q Item-->

        <div class="row faq-item d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="400">
          <div class="col-lg-5">
            <i class="ri-question-line"></i>
            <h4>Apakah pengaduan ini akan memengaruhi nilai kami?</h4>
          </div>
          <div class="col-lg-7">
            <p>
             Tidak. Website ini dari awal dibuat hanya sebagai wadah bagi keluhan mahasiswa agar bisa disimpan sebagai data acuan untuk perbaikan kedepannya. 
            </p>
          </div>
        </div><!-- End F.A.Q Item-->

        <div class="row faq-item d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="500">
          <div class="col-lg-5">
            <i class="ri-question-line"></i>
            <h4>Apakah kami bisa melihat pengaduan yang dibuat oleh mahasiswa lain?</h4>
          </div>
          <div class="col-lg-7">
            <p>
             Tidak bisa. Isi pengaduan hanya bisa dilihat melalui akun yang menulis dan tidak bisa diakses oleh akun lain. 
            </p>
          </div>
        </div><!-- End F.A.Q Item-->

      </div>
    </section><!-- End F.A.Q Section -->



    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>Contact Us</h2>
        </div>

        <div class="row">

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <div class="contact-about">
              <h3>PM-TI</h3>
              <p>Silahkan hubungi salah satu kontak yang disediakan jika terdapat masalah pada website ini. Terimakasih. <br> Semoga harimu menyenangkan</p>
              <div class="social-links">
                <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
                <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
                <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
                <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="200">
            <div class="info">
              <div>
                <i class="ri-map-pin-line"></i>
                <p>Jurusan Teknologi Informasi, Udayana</p>
              </div>

              <div>
                <i class="ri-mail-send-line"></i>
                <p>info@pmti.com</p>
              </div>

              <div>
                <i class="ri-phone-line"></i>
                <p>087866771948</p>
              </div>

            </div>
          </div>

          <div class="col-lg-5 col-md-12" data-aos="fade-up" data-aos-delay="300">
            <form action="kontak.php" method="post" class="php-email-form">
              <div class="form-group">
                <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
              </div>
              <div class="form-group">
                <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
              </div>
              <div class="form-group">
                <textarea class="form-control" name="message" rows="5" placeholder="Message" required></textarea>
              </div>
              <div class="text-center"><button type="submit">Send Message</button></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->
