<?php include "admin/koneksi.php";
session_start();
    if ($_SESSION['nama'] != true)  {
        header ("location:../login.php?pesan=belum_login");
    };     
    ?>
<br> <br> <br>
<section id="portfolio" class="portfolio">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>Buat Pengaduan </h2>
          <p>Pilih bagian yang terdapat masalah!</p>
        </div>

        <div class="row" data-aos="fade-up" data-aos-delay="200">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="portfolio-flters">
            <li data-filter="*" class="filter-active">Semua Form</li>
              <li data-filter=".filter-app">Sarana & Prasarana</li>
              <li data-filter=".filter-card">Staff</li>
              <li data-filter=".filter-web">Tenaga Pengajar</li>
            </ul>
          </div>
        </div>

        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="400">

        <!-- FORM PENGADUAN SARPRAS -->
          <div class="col-lg-12 col-md-12 portfolio-item filter-app">
            <div class="pengaduan-sarpras">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title" style="text-align:center">Pengaduan Sarana & Prasarana</h5>
                        <form method="post" action="tambah_pengaduan_sarpras.php" >
                            <div class="row mb-3">
                            <div class="col-sm-12">
                            <label  class="col-sm-2 col-form-label">Masukkan Keluhan</label>
                            <textarea name="keluhan" class="form-control" id="" cols="30" rows="10"></textarea>
                            </div>
                            </div>
                            <div class="row mb-3">
                            <div class="col-sm-12">
                                <button type="submit"  onclick="return confirm('Kirim Data Sekarang?')" class="btn btn-primary" >Submit Form</button>
                            </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
          </div>
        <!-- BATAS FORM PENGADUAN SARPRAS -->



        <!-- FORM PENGADUAN PENGAJAR -->
          <div class="col-lg-12 col-md-12 portfolio-item filter-web">
            <div class="pengaduan-pengajar">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title" style="text-align:center">Pengaduan Tenaga Pengajar</h5>
                        <form method="post" action="tambah_pengaduan_pengajar.php" >
                            <div class="row mb-3">
                            <div class="col-sm-12">
                            <label  class="col-sm-2 col-form-label">Masukkan Keluhan</label>
                            <textarea name="keluhan" class="form-control" id="" cols="30" rows="10"></textarea>
                            </div>
                            </div>
                            <div class="row mb-3">
                            <div class="col-sm-12">
                                <button type="submit"  onclick="return confirm('Kirim Data Sekarang?')" class="btn btn-primary">Submit Form</button>
                            </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
          </div>
          <!-- BATAS FORM PENGADUAN PENGAJAR -->



        <!-- FORM PENGADUAN STAFF -->
          <div class="col-lg-12 col-md-12 portfolio-item filter-card">
            <div class="pengaduan-staff">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title" style="text-align:center">Pengaduan Staff</h5>
                        <form method="post" action="tambah_pengaduan_staff.php" >
                            <div class="row mb-3">
                            <div class="col-sm-12">
                            <label  class="col-sm-2 col-form-label">Masukkan Keluhan</label>
                            <textarea name="keluhan" class="form-control" id="" cols="30" rows="10"></textarea>
                            </div>
                            </div>
                            <div class="row mb-3">
                            <div class="col-sm-12">
                                <button type="submit"   onclick="return confirm('Kirim Data Sekarang?')"class="btn btn-primary">Submit Form</button>
                            </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
          </div>
          <!-- BATAS FORM PENGADUAN STAFF -->

          
        </div>

      </div>
    </section><!-- End Portfolio Section -->