<?php 
    session_start();
//di destroy dulu baru di link
    session_destroy();

    header("location:index.php");
?>